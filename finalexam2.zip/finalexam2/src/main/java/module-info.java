module com.example.finalexam2 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.finalexam2 to javafx.fxml;
    exports com.example.finalexam2;
}