package com.example.finalexam2;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class StudentManagementSystem {
    public static void main(String[] args) {
        List<Student> students = new ArrayList<>();

        // Adding sample students
        Student student1 = new Student("S001", "Khushi", 20);
        student1.addCourse("Computer Science");
        student1.addCourse("Mathematics");
        students.add(student1);

        Student student2 = new Student("S002", "Mansi", 22);
        student2.addCourse("Physics");
        student2.addCourse("Chemistry");
        students.add(student2);

        Student student3 = new Student("S003", "Nidhi", 21);
        student3.addCourse("Computer Science");
        student3.addCourse("History");
        students.add(student3);

        // Display details of all students
        System.out.println("Details of all students:");
        students.forEach(Student::displayDetails);

        // Display students enrolled in a specific course (e.g., "Computer Science")
        String specificCourse = "Computer Science";
        System.out.println("Students enrolled in " + specificCourse + ":");
        students.stream()
                .filter(student -> student.getCourses().contains(specificCourse))
                .forEach(Student::displayDetails);

        // Update the age of a specific student
        String studentIDToUpdate = "S002";
        int newAge = 23;
        students.stream()
                .filter(student -> student.getStudentID().equals(studentIDToUpdate))
                .findFirst()
                .ifPresent(student -> student.setAge(newAge));

        // Display details of all students after the age update
        System.out.println("Details of all students after age update:");
        students.forEach(Student::displayDetails);

        // Calculate and display the average age of all students
        double averageAge = students.stream()
                .mapToInt(Student::getAge)
                .average()
                .orElse(0.0);
        System.out.println("Average age of all students: " + averageAge);
    }
}